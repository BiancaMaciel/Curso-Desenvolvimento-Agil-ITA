package primeiroexercicio.org.br;
/*
 
Instru��es

Implemente no Eclipse uma classe chamada Paciente que possui um construtor que recebe o seu peso em quilos e sua altura em metros, ambos utilizando o tipo double. Crie um m�todo chamado calcularIMC() que calcula o �ndice de Massa Corporal de acordo com a f�rmula IMC = peso (quilos) / (altura * altura (metros)). Crie tamb�m um m�todo chamado diagnostico() que utiliza o m�todo calcularIMC() e retorna uma String de acordo com as seguintes faixas de valor:

    Baixo peso muito grave = IMC abaixo de 16 kg/m�
    Baixo peso grave = IMC entre 16 e 16,99 kg/m�
    Baixo peso = IMC entre 17 e 18,49 kg/m�
    Peso normal = IMC entre 18,50 e 24,99 kg/m�
    Sobrepeso = IMC entre 25 e 29,99 kg/m�
    Obesidade grau I = IMC entre 30 e 34,99 kg/m�
    Obesidade grau II = IMC entre 35 e 39,99 kg/m�
    Obesidade grau III (obesidade m�rbida) = IMC igual ou maior que 40 kg/m�

Implemente no Eclipse uma classe chamada Principal em que se criam 3 inst�ncias da classe Paciente com valores diferentes e se imprime no console o resultado dos dois m�todos criados.

 */
public class Paciente {
	
	double peso, altura;
	
	public Paciente(double peso, double altura) {
		this.peso = peso;
		this.altura = altura;
	}
	
	public double calcularIMC(){
		return this.peso / (this.altura * this.altura); 
	}
	
	public String diagnostico(){
		
		double calcImc = calcularIMC();
		if(calcImc < 16)
			return "Baixo peso muito grave";
		if(calcImc >= 16 && calcularIMC() <= 16.99)
			return "Baixo peso grave";
		if(calcImc >= 17 && calcularIMC() <= 18.49)
			return "Baixo peso";
		if(calcImc >= 18.50 && calcularIMC() <= 24.99)
			return "Peso normal";		
		if(calcImc >= 25 && calcularIMC() <= 29.99)
			return "Sobrepeso";
		if(calcImc >= 30 && calcularIMC() <= 34.99)
			return "Obesidade grau I";
		if(calcImc >= 35 && calcularIMC() <= 39.99)
			return "Obesidade grau II";
		if(calcImc >= 40)
			return "Obesidade grau III (obesidade m�rbida)";
		return null;
	}
}