package primeiroexercicio.org.br;

public class Principal {

	public static void main(String[] args) {
		
		Paciente p1 = new Paciente(78, 1.75);
		System.out.println(p1.calcularIMC());
		System.out.println(p1.diagnostico() + "\n");
		

		Paciente p2 = new Paciente(104, 1.82);
		System.out.println(p2.calcularIMC());
		System.out.println(p2.diagnostico() + "\n");
		

		Paciente p3 = new Paciente(70, 1.60);
		System.out.println(p3.calcularIMC());
		System.out.println(p3.diagnostico() + "\n");
		

		Paciente p4 = new Paciente(90, 1.60);
		System.out.println(p4.calcularIMC());
		System.out.println(p4.diagnostico() + "\n");
		
		Paciente p5 = new Paciente(150, 1.60);
		System.out.println(p5.calcularIMC());
		System.out.println(p5.diagnostico() + "\n");

		Paciente p6 = new Paciente(45, 1.60);
		System.out.println(p6.calcularIMC());
		System.out.println(p6.diagnostico() + "\n");

		Paciente p7 = new Paciente(50, 1.60);
		System.out.println(p7.calcularIMC());
		System.out.println(p7.diagnostico() + "\n");

		Paciente p8 = new Paciente(35, 1.60);
		System.out.println(p8.calcularIMC());
		System.out.println(p8.diagnostico() + "\n");

		Paciente p9 = new Paciente(43, 1.60);
		System.out.println(p9.calcularIMC());
		System.out.println(p9.diagnostico() + "\n");

		Paciente p = new Paciente(0,0);
		System.out.println(p.calcularIMC());
		
	}

}
