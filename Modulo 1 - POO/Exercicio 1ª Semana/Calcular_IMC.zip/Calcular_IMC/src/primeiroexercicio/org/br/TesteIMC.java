package primeiroexercicio.org.br;

import static org.junit.Assert.*;

import org.junit.Test;

public class TesteIMC {

	@Test
	public void testBaixoPesoMG() {
		Paciente p8 = new Paciente(35, 1.60);
		assertEquals(13.67, p8.calcularIMC(), 10);
		assertEquals("Baixo peso muito grave", p8.diagnostico());
	}

	@Test
	public void testBaixoPesoGrave() {
		Paciente p9 = new Paciente(43, 1.60);
		assertEquals(13.67, p9.calcularIMC(), 10);
		assertEquals("Baixo peso grave", p9.diagnostico());

	}
	
	@Test
	public void testBaixoPeso() {
		Paciente p6 = new Paciente(45, 1.60);
		assertEquals(17.57, p6.calcularIMC(), 10);
		assertEquals("Baixo peso", p6.diagnostico());
	}
	
	@Test
	public void testPesoNormal() {
		Paciente p7 = new Paciente(50, 1.60);
		assertEquals(19.53, p7.calcularIMC(), 10);
		assertEquals("Peso normal", p7.diagnostico());
	}

	@Test
	public void testSobrePeso() {
		Paciente p1 = new Paciente(78, 1.75);
		assertEquals(25.46, p1.calcularIMC(), 10);
		assertEquals("Sobrepeso", p1.diagnostico());
	}
	
	@Test
	public void testObesidadeGrauI() {
		Paciente p2 = new Paciente(104, 1.82);
		assertEquals(31.39, p2.calcularIMC(), 10);
		assertEquals("Obesidade grau I", p2.diagnostico());
	}
	
	@Test
	public void testObesidadeGrauII() {
		Paciente p4 = new Paciente(90, 1.60);
		assertEquals(35.15, p4.calcularIMC(), 10);
		assertEquals("Obesidade grau II", p4.diagnostico());
	}
	
	@Test
	public void testObesidadeGrauIII() {
		Paciente p5 = new Paciente(150, 1.60);
		assertEquals(58.59, p5.calcularIMC(), 10);
		assertEquals("Obesidade grau III (obesidade m�rbida)", p5.diagnostico());
	}
}