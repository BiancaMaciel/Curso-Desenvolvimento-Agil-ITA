import java.util.ArrayList;

public class CarrinhoDeCompras {
	
	private ArrayList<Pizza> qntPizzas = new ArrayList<Pizza>();
	private int somaValoresTodasPizzas = 0;
	
	public void addPizza(Pizza p)
	{
		if(p.ingredientesDeCadaPizza == 0)
			System.out.println("ATEN��O!!!!\n Adicione um ingrediente!!!");
		else
		{
			qntPizzas.add(p);
			somaValoresTodasPizzas += p.getPreco();
		}
			
	}
	
	public int valoresPizzas()
	{
		System.out.println("Foram add " + qntPizzas.size() + " pizzas!");
		return somaValoresTodasPizzas;
	}

	public int getQntPizzas()
	{
		return qntPizzas.size();
	}
	
	public int getSomaValoresTodasPizzas()
	{
		return somaValoresTodasPizzas;
	}
}