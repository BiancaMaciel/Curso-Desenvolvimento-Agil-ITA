
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pizza p1 = new Pizza();
		p1.adicionaIngrediente("Cebola");
		p1.adicionaIngrediente("Milho");
		
		Pizza p2 = new Pizza();
		p2.adicionaIngrediente("Cebola");
		p2.adicionaIngrediente("Bacon");
		p2.adicionaIngrediente("Calabresa");
		
		Pizza p3 = new Pizza();
		p3.adicionaIngrediente("Tomate");
		p3.adicionaIngrediente("Frango");
		p3.adicionaIngrediente("Azeitona");
		p3.adicionaIngrediente("Queijo");
		p3.adicionaIngrediente("Presunto");
		p3.adicionaIngrediente("Peito de Peru");
		
		Pizza p4 = new Pizza();
		
		
		CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		carrinho.addPizza(p1);
		carrinho.addPizza(p2);
		carrinho.addPizza(p3);
		carrinho.addPizza(p4);

		System.out.println("Total do CarrinhoDeCompra: " + carrinho.valoresPizzas() + " reais");
		System.out.println("---------");
		
		System.out.println("Quantidade utilizada de cada ingrediente! ");
		p1.qntDeCadaIngrediente();
		
	}

}
