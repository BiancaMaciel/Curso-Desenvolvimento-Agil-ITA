import static org.junit.Assert.*;

import org.junit.Test;


public class TesteCarrinho {

	@Test
	public void testAdd() {
		CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		//primeiro add as pizzas no carrinho
		for(int i = 0; i < 3; i++)
		{   
			Pizza p = new Pizza();
			p.adicionaIngrediente("Cebola");
			p.adicionaIngrediente("Bacon");
			p.adicionaIngrediente("Calabresa");
			carrinho.addPizza(p);	
		}
		assertEquals(3, carrinho.getQntPizzas());
		//segundo ver o valor das pizzas no carrinho
		assertEquals(60, carrinho.getSomaValoresTodasPizzas());
	}
	
	@Test
	public void testPizzaVazia() {
		//impedir a adi��o de uma pizza sem ingredientes.
		Pizza p4 = new Pizza();
		CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		carrinho.addPizza(p4);
		assertEquals(0, carrinho.getQntPizzas());
	}
}