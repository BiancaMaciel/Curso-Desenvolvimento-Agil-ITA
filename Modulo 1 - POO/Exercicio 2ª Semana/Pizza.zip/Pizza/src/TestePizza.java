import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class TestePizza {

	@Test
	public void testPizza1() {
		//verifique se o valor da Pizza est� correto de acordo com a quantidade de ingredientes. 
		Pizza p1 = new Pizza();
		p1.adicionaIngrediente("Cebola");
		p1.adicionaIngrediente("Milho");
		assertEquals(15, p1.getPreco());}
	
	@Test
	public void testPizza2() {
		//verifique se o valor da Pizza est� correto de acordo com a quantidade de ingredientes. 
		Pizza p2 = new Pizza();
		p2.adicionaIngrediente("Cebola");
		p2.adicionaIngrediente("Bacon");
		p2.adicionaIngrediente("Calabresa");
		assertEquals(20, p2.getPreco());}
	
	@Test
	public void testRegistro() {
		//Verifique tamb�m se o registro de ingredientes funcionou corretamente. 
		Pizza registro = new Pizza();
		registro.adicionaIngrediente("Tomate");
		registro.adicionaIngrediente("Frango");
		registro.adicionaIngrediente("Azeitona");
		registro.adicionaIngrediente("Queijo");
		assertEquals(4, registro.qntIngTodasPizzas);}
   
	@After
	public void testLimpaRegistro() {
		/*
		 Crie um m�todo est�tico na classe Pizza que zera o registro de ingredientes e invoque ele em um m�todo de inicializa��o ou finaliza��o na classe de testes.*/
		Pizza limpaRegistro = new Pizza();
		limpaRegistro.adicionaIngrediente("Tomate");
		limpaRegistro.adicionaIngrediente("Frango");
		limpaRegistro.adicionaIngrediente("Azeitona");
		limpaRegistro.adicionaIngrediente("Queijo");
		int i = limpaRegistro.limpaRegistro();
		assertEquals(0, i);
	}
   
}
