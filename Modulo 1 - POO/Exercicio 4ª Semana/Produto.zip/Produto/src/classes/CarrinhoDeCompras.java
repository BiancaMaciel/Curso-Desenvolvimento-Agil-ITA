package classes;
import java.util.HashMap;
import java.util.Map;


public class CarrinhoDeCompras {

	private int quantidadeProduto;
	private int totalProd;

	HashMap<Produto, Integer> map = new HashMap<Produto, Integer>();
	
	/**
	 * @return the totalProd
	 */
	public int getTotalProd() {
		return totalProd;
	}


	/**
	 * @param totalProd the totalProd to set
	 */
	public void setTotalProd(int totalProd) {
		this.totalProd = totalProd;
	}


	public void adicionaProduto(Produto p, int quantidade)
	{
		if(!map.containsKey(p))
		{
			map.put(p, 1);

			setQuantidadeProduto(quantidade);
		}else{
			int qntd = map.get(p) +1;
			map.put(p, qntd);
			setQuantidadeProduto(quantidade);
		}
	}
	

	public int getQuantidadeProduto() {
		return quantidadeProduto;
	}

	public void setQuantidadeProduto(int quantidadeProduto) {
		this.quantidadeProduto = quantidadeProduto;
	}

	public int removeProduto(Produto p, int qntRemovida) 
	{
		int diferenca = Math.abs(this.quantidadeProduto - qntRemovida);
	
		if(map.containsKey(p))
		{
			for(int i = qntRemovida; i >= diferenca ; i--)
			{
				map.remove(i);
			}
			totalProd = map.get(p).valueOf(diferenca);
		}
		return totalProd;
	}
	public double valorTotalCompra()
	{
		float total = 0;
		for (Produto p : map.keySet()) {
			total += p.getPreco() * this.quantidadeProduto;
		}
		return total;
	}
}
