package classes;
/*
 * Instru��es

Crie uma classe chamada Produto que deve possuir um nome, um c�digo e um pre�o. Sobrescreva os m�todos equals() e hashCode() de Object (veja se��o sobre esses m�todos), de forma a serem considerados iguais instancias de Produto que possuam o mesmo c�digo.

Crie uma classe chamada ProdutoComTamanho que estenda a classe Produto. Essa classe deve possuir uma informa��o adicional de tamanho. Um exemplo seria o tamanho de uma roupa ou a numera��o de um cal�ado. M�todo equals() e hashCode() devem ser sobrescritos de forma que um produto com mesmo c�digo e tamanhos diferentes s�o considerados diferentes.

Crie uma classe CarrinhoDeCompras que armazene em um atributo interno do tipo HashMap cada produto adicionado no carrinho e sua respectiva quantidade. O m�todo adicionaProduto() deve receber a instancia do produto e a quantidade. Caso o produto j� exista no HashMap, a quantidade deve ser somada a que j� existe no carrinho. Deve haver tamb�m um m�todo removeProduto() que tamb�m recebe a instancia do produto e a quantidade a ser removida. Observe que produtos de tamanhos diferentes devem ser considerados como produtos diferentes no carrinho. O carrinho deve possuir um m�todo que calcula o valor total da compra.

Crie testes com Unit para a classe Produto, para a classe ProdutoComTamanho e para a classe CarrinhoDeCompras. Os testes de cada classe devem ser colocados em classes separadas e devem estar em um diret�rio de c�digo diferente das classes de produ��o.

 */
public class Produto {
	// obs:  de forma a serem considerados iguais instancias de Produto que possuam o mesmo c�digo.
	private String nome;
	private int codigo;
	private float preco;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	public Produto(String nome, int codigo, float preco)
	{
		this.nome = nome;
		this.codigo = codigo;
		this.preco = preco;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + codigo;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Produto)) {
			return false;
		}
		Produto other = (Produto) obj;
		if (codigo != other.codigo) {
			return false;
		}
		if (nome == null) {
			if (other.nome != null) {
				return false;
			}
		} else if (!nome.equals(other.nome)) {
			return false;
		}
		if (Float.floatToIntBits(preco) != Float.floatToIntBits(other.preco)) {
			return false;
		}
		return true;
	}

}
