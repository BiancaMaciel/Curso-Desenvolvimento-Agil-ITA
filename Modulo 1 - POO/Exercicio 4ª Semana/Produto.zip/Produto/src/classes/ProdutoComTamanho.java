package classes;

public class ProdutoComTamanho extends Produto {
	
	/*
	 * M�todo equals() e hashCode() 
	 * devem ser sobrescritos de forma que um produto com mesmo c�digo e tamanhos diferentes s�o considerados diferentes.
	 */
	int tamanho;
	
	public ProdutoComTamanho(String nome, int codigo, float preco, int tamanho) {
		super(nome, codigo, preco);
		this.setNome(nome);
		this.setCodigo(codigo);
		this.setPreco(preco);
		this.tamanho = tamanho;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + tamanho;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ProdutoComTamanho)) {
			return false;
		}
		ProdutoComTamanho other = (ProdutoComTamanho) obj;
		if (tamanho != other.tamanho) {
			return false;
		}
		return true;
	}
}