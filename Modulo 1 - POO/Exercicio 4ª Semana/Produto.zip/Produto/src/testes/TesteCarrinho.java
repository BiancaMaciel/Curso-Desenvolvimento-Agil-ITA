package testes;

import static org.junit.Assert.*;

import org.junit.Test;

import classes.CarrinhoDeCompras;
import classes.Produto;

public class TesteCarrinho {

	@Test
	public void testAddProd() {
		Produto p = new Produto("p1", 12, 50);
		CarrinhoDeCompras c = new CarrinhoDeCompras();
		c.adicionaProduto(p, 10);
		assertEquals(10, c.getQuantidadeProduto());
	}

	@Test
	public void testRemoveTodosProd() {
		Produto p = new Produto("p1", 12, 50);
		CarrinhoDeCompras c = new CarrinhoDeCompras();
		c.adicionaProduto(p, 10);
		int remover  = c.removeProduto(p, 10);
		assertEquals("removeu produto?", 0, remover);
	
	}
	@Test
	public void testRemoveQuaseTdsProd() {
		Produto p = new Produto("p1", 12, 50);
		CarrinhoDeCompras c = new CarrinhoDeCompras();
		c.adicionaProduto(p, 10);
		int remover  = c.removeProduto(p, 8);
		assertEquals("removeu produto?", 2, remover);
	}
	@Test
	public void testTotalProd() {
		Produto p = new Produto("p1", 12, 50);
		CarrinhoDeCompras c = new CarrinhoDeCompras();
		c.adicionaProduto(p, 10); 
		assertEquals("Total correto?", 500, c.valorTotalCompra(), 0);
	}
}
