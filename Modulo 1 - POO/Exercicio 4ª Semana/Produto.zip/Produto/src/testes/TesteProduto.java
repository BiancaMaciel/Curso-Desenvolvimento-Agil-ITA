package testes;

import static org.junit.Assert.*;

import org.junit.Test;

import classes.Produto;


public class TesteProduto {

	@Test
	public void testProdIguais() {
		Produto p1 = new Produto("Produto1", 123, 65);
		Produto p2 = new Produto("Produto1", 123, 65);
		assertTrue("Produtos iguais" , p1.equals(p2));
	}
	@Test
	public void testProdDiferentes() {
		Produto p1 = new Produto("Produto1", 123, 65);
		Produto p2 = new Produto("Produto2", 1234, 68);
		assertFalse("Produtos iguais" , p1.equals(p2));
	}
}
