package testes;

import static org.junit.Assert.*;

import org.junit.Test;

import classes.Produto;
import classes.ProdutoComTamanho;

public class TesteProdutoComTamanho {

	@Test
	public void testProdutosIguais() {
		Produto p1 = new ProdutoComTamanho("p1", 123, 50, 10);
		Produto p2 = new ProdutoComTamanho("p1", 123, 50, 10);
		assertTrue("ProdutosIguais?" , p1.equals(p2));
	}
	
	@Test
	public void testProdutosDif() {
		Produto p1 = new ProdutoComTamanho("p2", 123, 50, 10);
		Produto p2 = new ProdutoComTamanho("p2", 123, 150, 10);
		assertFalse("ProdutosIguais?" , p1.equals(p2));
	}
	
}