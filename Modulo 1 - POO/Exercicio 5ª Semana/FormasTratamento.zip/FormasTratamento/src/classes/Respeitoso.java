package classes;

public class Respeitoso implements FormatadorNome {

	String sexo;
	public Respeitoso(String sexo)
	{
		this.sexo = sexo;
	}
	@Override
	public String formatarNome(String nome, String sobrenome) {
		
		if(sexo.contains("f") || sexo.contains("Feminino"))
		{	
			return "Sra. " + sobrenome;
		}	
		else { 
			return "Sr. " + sobrenome; 
		}
	}

}
