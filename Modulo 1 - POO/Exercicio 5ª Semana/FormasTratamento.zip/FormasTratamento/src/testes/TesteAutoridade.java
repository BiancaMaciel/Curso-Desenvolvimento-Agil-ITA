package testes;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import classes.Autoridade;
import classes.ComTitulo;
import classes.Informal;
import classes.Respeitoso;


public class TesteAutoridade {

	@Test
	public void testInformal() {
		Informal informal = new Informal();
		Autoridade autoridade = new Autoridade(informal, "Thiago", "Araujo");
		assertEquals("Thiago", autoridade.getTratamento());
	}
	@Test
	public void testRespeitosoM() {

		Respeitoso respeitoso = new Respeitoso("m");		
		Autoridade autoridade = new Autoridade(respeitoso, "Thiago", "Araujo");
		assertEquals("Sr. Araujo", autoridade.getTratamento());
	}
	@Test
	public void testComTitulo() {
		ComTitulo comTitulo = new ComTitulo("Chefe");
		Autoridade autoridade = new Autoridade(comTitulo, "Vanessa", "Araujo");
		assertEquals("Chefe Vanessa Araujo", autoridade.getTratamento());
	}
}
