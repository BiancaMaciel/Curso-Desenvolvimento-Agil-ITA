package classes;


import java.util.Random;

public class BancoDePalavras {
	
	/*
	 * classe que possui um m�todo que retorna uma palavra retirada
aleat�riamente de uma lista de palavras lida a partir de um arquivo.
	 */

	public String geraPalavraAleatoria()
	{
		Utils utils = new Utils();
		//lendo o arquivo que cont�m todas as palavras
		utils.leituraArquivoTodasPalavras();
		
		//escolhendo a partir do id do array uma palavra
		Random random = new Random();
		int index = random.nextInt(utils.armazenarPalavras.size());
		String palavra = utils.armazenarPalavras.get(index);
		
		//salvando no arquivo a palavra Original
		utils.salvarPalavraOriginal(palavra);
		
		return utils.armazenarPalavras.get(index);
	} 
}