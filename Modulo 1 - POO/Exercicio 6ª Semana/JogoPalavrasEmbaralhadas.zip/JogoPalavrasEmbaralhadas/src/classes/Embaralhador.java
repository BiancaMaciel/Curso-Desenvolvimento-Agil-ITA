package classes;

public interface Embaralhador {

	public String palavraEmbaralhada();
}
