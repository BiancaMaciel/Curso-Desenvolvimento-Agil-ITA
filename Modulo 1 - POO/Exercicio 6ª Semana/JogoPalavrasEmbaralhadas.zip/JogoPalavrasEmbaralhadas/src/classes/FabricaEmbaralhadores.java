package classes;

import java.util.Random;

public class FabricaEmbaralhadores {

/*
 * : possui um m�todo que retorna um embaralhador
aleat�riamente
 */
	public String escolherUmEmbaralhador()
	{
		String palavra = "";
		Embaralhador em;
		Random random = new Random();
		int index = random.nextInt(2);
		
		if(index == 0)
		{
			 em = new InverterPalavras();
			 palavra = em.palavraEmbaralhada();
			 return palavra;
		}
		em = new VogaisEConsoantes();
		palavra = em.palavraEmbaralhada();
		return palavra;
	}
}