package classes;

import java.util.Random;

public class FabricaMecanicaDoJogo {

	private String palavraConsole;
	private String mandarMsgParaPrincipal;

	public String getMandarMsgParaPrincipal() {
		return mandarMsgParaPrincipal;
	}

	public void setMandarMsgParaPrincipal(String mandarMsgParaPrincipal) {
		this.mandarMsgParaPrincipal = mandarMsgParaPrincipal;
	}

	public FabricaMecanicaDoJogo(String palavra)
	{
		this.palavraConsole = palavra;
	}
	
	public void mecanicaDoJogo()
	{
		MecanicaDoJogo mecanica;
		Random random = new Random();
		int index = random.nextInt(2);
		
		if(index == 0)
		{
			mecanica = new TiraPontosEDiminuiChances(palavraConsole);
			mecanica.statusJogo();
		}
		else
		{	
			mecanica = new MensagemJogo(palavraConsole);
			mecanica.statusJogo();
		}
		this.setMandarMsgParaPrincipal(mecanica.mensagem());
	}
}
