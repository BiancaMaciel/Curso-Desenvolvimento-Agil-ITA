package classes;

public class InverterPalavras implements Embaralhador{

	private String palavra;
	boolean isTeste = false;
	String resultado = "";
	public boolean isTeste() {
		return isTeste;
	}

	public void setTeste(boolean isTeste) {
		this.isTeste = isTeste;
	}

	public void setPalavra(String palavra)
	{
		this.palavra = palavra;
	}
	
	public String getPalavra()
	{
		return this.palavra;
	}

	
	@Override
	public String palavraEmbaralhada() {
		if(isTeste == false)
		{
			BancoDePalavras bp = new BancoDePalavras();
			setPalavra(bp.geraPalavraAleatoria());
			inverterPalavra();
		}
		else
		{
			inverterPalavra();
		}
		return resultado;
	}
	
	public void inverterPalavra()
	{
		for(int i = this.getPalavra().length()-1; i >= 0; i--)
			resultado+= this.getPalavra().charAt(i);
	}
}