package classes;

public interface MecanicaDoJogo {
	public void statusJogo();
	public String mensagem();
}
