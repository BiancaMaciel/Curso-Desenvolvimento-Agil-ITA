package classes;

public class MensagemJogo implements MecanicaDoJogo{

	private String palavraConsole;
	private String mensagem;

	Utils utils = new Utils();

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public MensagemJogo(String palavraConsole) {
		this.palavraConsole = palavraConsole;
	}
	
	@Override
	public void statusJogo() {
		TiraPontosEDiminuiChances t = new TiraPontosEDiminuiChances(palavraConsole);
		t.statusJogo();
		String m = utils.leituraArquivoStatus();
		if(m.equals("vencedor"))
		{
			setMensagem("Parab�ns voc� ganhou!!!");
		}
		else
		{
			setMensagem("Infelizmente n�o foi dessa vez!!!");
		}
	}

	@Override
	public String mensagem() {
		return this.getMensagem();
	}
}