package classes;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {				
		FabricaEmbaralhadores fe = new FabricaEmbaralhadores();
		System.out.println(fe.escolherUmEmbaralhador());

		Scanner sc = new Scanner(System.in);
		String entrada = sc.nextLine();
		
		FabricaMecanicaDoJogo mecanica = new FabricaMecanicaDoJogo(entrada);
		mecanica.mecanicaDoJogo();
		System.out.println(mecanica.getMandarMsgParaPrincipal());
	}
}