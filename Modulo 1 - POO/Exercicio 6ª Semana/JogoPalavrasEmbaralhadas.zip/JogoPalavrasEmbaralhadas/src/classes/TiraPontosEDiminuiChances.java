package classes;

import java.util.ArrayList;

public class TiraPontosEDiminuiChances implements MecanicaDoJogo{

	ArrayList<String> arrayConsole = new ArrayList<String>();
	int pontos = 30 , tentativas = 0;
	Utils utils = new Utils();

	private String mensagem, mensagem2;
	
	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getMensagem2() {
		return mensagem2;
	}

	public void setMensagem2(String mensagem2) {
		this.mensagem2 = mensagem2;
	}

	public TiraPontosEDiminuiChances(String entrada)
	{
		arrayConsole.add(entrada);
	}

	public void statusJogo()
	{	//lendo o arquivo com a palavra original para fazer as compara��es
		utils.leituraArquivoPalavrasOriginais();
	
		for(int i = 0; i < utils.arrayPalavraOriginal.size(); i++)
		{
			
			for(int k = 0; k < arrayConsole.size(); k++)
			{
				if((utils.arrayPalavraOriginal.get(i).equals(arrayConsole.get(k))) && tentativas == 0)
				{
					setMensagem("Total de vidas: " + tentativas);
					setMensagem2("\nTotal de Pontos: " + pontos * 10);
					utils.salvarStatus("vencedor");
				}	
				else if(!utils.arrayPalavraOriginal.equals(arrayConsole))
				{
					tentativas = 0;
					pontos = Math.abs( pontos - pontos);
					setMensagem("Total de vidas: " + tentativas);
					setMensagem2("\nTotal de Pontos: " + pontos);
					utils.salvarStatus("perdedor");					
				}				
			}		
		}
	}

	@Override
	public String mensagem() {
		return getMensagem() + " " + getMensagem2();
	}
}