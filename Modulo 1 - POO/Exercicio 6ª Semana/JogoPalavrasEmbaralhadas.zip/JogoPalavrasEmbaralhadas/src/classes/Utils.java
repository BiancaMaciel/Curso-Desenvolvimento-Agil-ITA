package classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;

public class Utils implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String palavraOriginal;
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	ArrayList<String> armazenarPalavras = new ArrayList<String>();
	ArrayList<String> arrayPalavraOriginal = new ArrayList<String>();

	
	public String getPalavraOriginal() {
		return palavraOriginal;
	}

	public void setPalavraOriginal(String palavraOriginal) {
		this.palavraOriginal = palavraOriginal;
	}
	

	public void leituraArquivoTodasPalavras()
	{
		try{
			FileReader file = new FileReader("txtPalavras.txt");
			BufferedReader buff = new BufferedReader(file);
			String linha;
			while((linha = buff.readLine()) != null)
			{
				String a = linha;
				armazenarPalavras.add(a);
			}
			buff.close();
		}catch (IOException e)
		{
			
		}
	}
	public void salvarPalavraOriginal(String palavra)
	{

		try{
			FileWriter arq = new FileWriter("palavrasOriginais.txt"); 
			PrintWriter gravarArq = new PrintWriter(arq); 
			gravarArq.print(palavra);
			arq.close();

		}
		catch(IOException e)
		{
		}
	}

	public void leituraArquivoPalavrasOriginais()
	{
		try{
			FileReader file = new FileReader("palavrasOriginais.txt");
			BufferedReader buff = new BufferedReader(file);
			String linha;
			while((linha = buff.readLine()) != null)
			{
				String a = linha;
				arrayPalavraOriginal.add(a);
			}
			buff.close();
		}catch (IOException e)
		{
			
		}
	}
		
	public void salvarStatus(String palavra)
	{

		try{
			FileWriter arq = new FileWriter("status.txt"); 
			PrintWriter gravarArq = new PrintWriter(arq); 
			gravarArq.print(palavra);
			arq.close();

		}
		catch(IOException e)
		{
		}
	}

	public String leituraArquivoStatus()
	{
		try{
			FileReader file = new FileReader("status.txt");
			BufferedReader buff = new BufferedReader(file);
			String linha;
			while((linha = buff.readLine()) != null)
			{
				setStatus(linha);
			}
			buff.close();
		}catch (IOException e)
		{
			
		}
		return getStatus();
	}
}