package classes;


public class VogaisEConsoantes implements Embaralhador {

	private String palavra;
	boolean isTeste = false;

	String letrasConsoantes = "", letrasVogais = "", vogais ="aeiou";

	public boolean isTeste() {
		return isTeste;
	}

	public void setTeste(boolean isTeste) {
		this.isTeste = isTeste;
	}

	public void setPalavra(String palavra)
	{
		this.palavra = palavra;
	}
	
	public String getPalavra()
	{
		return this.palavra;
	}
	
	@Override
	public String palavraEmbaralhada() {
		
		if(isTeste == false)
		{
			BancoDePalavras bp = new BancoDePalavras();
			setPalavra(bp.geraPalavraAleatoria());
			separaConsoanteEVogal();
		}
		else
		{
			separaConsoanteEVogal();
		}
		return letrasVogais + letrasConsoantes;
	}
	
	public void separaConsoanteEVogal()
	{
		for(char c: this.getPalavra().toCharArray())
		{
			String s = String.valueOf(c);
			if (!vogais.contains(s)) {
				letrasConsoantes += s;
			}
			else{ 
				letrasVogais += s;
			}
		}	
	}
}