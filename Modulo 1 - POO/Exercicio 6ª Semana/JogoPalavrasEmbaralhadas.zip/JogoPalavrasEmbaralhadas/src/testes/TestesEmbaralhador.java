package testes;

import static org.junit.Assert.*;
import org.junit.Test;

import classes.InverterPalavras;
import classes.VogaisEConsoantes;

public class TestesEmbaralhador {

	@Test
	public void testInverterPalavras() {
		InverterPalavras ip = new InverterPalavras();
		ip.setTeste(true);
		ip.setPalavra("bianca");
		String palavra = ip.palavraEmbaralhada();
		assertEquals("acnaib", palavra);
	}
	
	@Test
	public void testVogaisEConsoantes() {
		VogaisEConsoantes vc = new VogaisEConsoantes();
		vc.setTeste(true);
		vc.setPalavra("bianca");
		String palavra = vc.palavraEmbaralhada();
		assertEquals("iaabnc", palavra);
	}
}